#include <stdio.h>

void printBye() {
	printf("Bye\n");
}

