#ifndef ALL_H
#define ALL_H

double power(double a, int b);
void printBye();
void printHello();

#endif
